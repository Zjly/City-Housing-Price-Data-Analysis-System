<template>
  <div>
    Account: 修改用户密码(敬请期待)
  </div>
</template>

<script>
export default {
  name: 'Account',  //this is the name of the component
}
</script>