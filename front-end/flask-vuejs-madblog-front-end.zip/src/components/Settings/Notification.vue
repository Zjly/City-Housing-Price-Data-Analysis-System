<template>
  <div>
    Notifications: 用户可以定制接收哪些提醒(敬请期待)
  </div>
</template>

<script>
export default {
  name: 'Notification',  //this is the name of the component
}
</script>