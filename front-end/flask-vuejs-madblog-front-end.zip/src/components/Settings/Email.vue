<template>
  <div>
    Email: 修改用户邮箱地址(敬请期待)
  </div>
</template>

<script>
export default {
  name: 'Email',  //this is the name of the component
}
</script>