<template>
  <div>
    全部私信
  </div>
</template>

<script>
export default {
  name: 'RecivedMessages',  //this is the name of the component
}
</script>